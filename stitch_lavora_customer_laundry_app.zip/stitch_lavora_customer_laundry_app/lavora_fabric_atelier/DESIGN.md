---
name: LAVORA Fabric Atelier
colors:
  surface: '#fcf8ff'
  surface-dim: '#dad6ff'
  surface-bright: '#fcf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f2ff'
  surface-container: '#efebff'
  surface-container-high: '#e9e5ff'
  surface-container-highest: '#e3dfff'
  on-surface: '#181445'
  on-surface-variant: '#4a4453'
  inverse-surface: '#2d2a5b'
  inverse-on-surface: '#f3eeff'
  outline: '#7b7485'
  outline-variant: '#ccc3d6'
  surface-tint: '#713dcc'
  primary: '#420093'
  on-primary: '#ffffff'
  primary-container: '#5b21b6'
  on-primary-container: '#c7aaff'
  inverse-primary: '#d3bbff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#003b27'
  on-tertiary: '#ffffff'
  tertiary-container: '#005439'
  on-tertiary-container: '#58cd9b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ebddff'
  primary-fixed-dim: '#d3bbff'
  on-primary-fixed: '#250059'
  on-primary-fixed-variant: '#581db3'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#fcf8ff'
  on-background: '#181445'
  surface-variant: '#e3dfff'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system expresses immaculate luxury, high precision, and contemporary garment care tailored specifically for discerning urban Indian households. The aesthetic marries the clinical confidence of modern textile science with the bespoke hospitality of an artisanal valet service. 

Key attributes:
- **Atmosphere**: Pristine, luminous, calming, and distinctly premium.
- **Visual Style**: Clean Modern Luxury layered with Subtle Glassmorphism and refined surface depth. Generous breathing room, precise micro-details, and smooth pill contours evoke treated silk, starched linen, and crisp fabrics.
- **Audience & Context**: Mobile-first everyday consumers who value their wardrobe investments. Interfaces prioritize rapid pickup scheduling, garment tracking fidelity, transparent pricing in Indian Rupees (₹), and crystal-clear service distinctions (e.g., Steam Ironing, Organic Dry Clean, Saree Preservation, Sneaker Valet).

## Colors

The palette balances royal violet authority with the freshness of aerated laundry water and natural botanicals.

- **Primary (`#5B21B6`)**: Royal Rich Violet. Imparts heritage, luxury, and premium authority. Used for prominent active app bars, hero primary actions, and brand badges.
- **Secondary (`#7C3AED`)**: Vibrant Electric Indigo. Guides user energy toward interactive touchpoints, selectable wash modes, progress states, and highlight borders.
- **Tertiary (`#059669`)**: Mint Emerald. Dedicated to positive reinforcement, completed stages, garment sanitization confirmation, and coupon savings. Paired with soft mint fills (`#ECFDF5`).
- **Warning / Operational Accent (`#D97706`)**: Warm Amber. Communicates items in transit, stain inspection warnings, or pending pickup slots.
- **Backgrounds & Canvas**: Surfaces rest on soft lavender mist (`#F5F3FF` base, `#EDE9FE` secondary tiers) rather than stark cold greys, retaining warmth and fabric softness. Elevated cards use pure `#FFFFFF` to signify unblemished cleanliness.
- **Text & Structure (`#1E1B4B` to `#0F172A`)**: Deep ink slate prevents harsh black contrast while maintaining AAA readability in high-glare ambient light.

## Typography

The type hierarchy employs **Plus Jakarta Sans** uniformly across headlines, body copy, and UI metadata. Its geometric construction, wide apertures, and clean curves deliver exceptional legibility on small handheld displays while echoing the rounded, fluid character of the design system.

- **Numerics & Rupee Formatting**: Currency amounts must consistently utilize tabular or semi-bold rendering (e.g., `₹1,249`) to guarantee glanceable clarity inside shopping baskets and service tallies.
- **Headings**: Tightly tracked headlines project editorial confidence.
- **Micro-labels**: Uppercase, tracked small labels (`label-sm`) are reserved for order stage indicators (`IN WASH`, `OZONE SANITIZED`, `OUT FOR VALET`).

## Layout & Spacing

A mobile-optimized fluid grid system anchors all views. Spacing reflects standard 4px and 8px touch increments, ensuring Android touch targets surpass the minimum 48x48dp threshold.

- **Mobile Viewport (Base)**: 4-column layout with `16px` outer canvas margins and `12px` to `16px` gutters. Elements fit naturally within single-hand thumb reach zones.
- **Tablet / Large Handheld**: 8-column layout with `24px` margins, anchoring checkout sheets and order tracking timelines to a balanced central column.
- **Vertical Rhythm**: Generous whitespace between service tiers (`space-xl`) prevents visual clutter, allowing rich imagery of fabric textures and treatment tags to breathe.

## Elevation & Depth

Visual depth combines tonal surface stepping with violet-tinted atmospheric diffusion rather than generic grey dropshadows:

1. **Base Layer (L0)**: `#F5F3FF` lavender mist background.
2. **Elevated Cards (L1)**: Pure `#FFFFFF` surface accompanied by an ultra-soft violet shadow: `0 8px 24px -4px rgba(91, 33, 182, 0.06), 0 2px 6px -1px rgba(30, 27, 75, 0.04)`.
3. **Floating & Modals (L2)**: Bottom sheets, active cart bars, and persistent action drawers feature `0 20px 40px -8px rgba(30, 27, 75, 0.16)`.
4. **Glass Badges & Translucent Overlays**: Semi-transparent chips (`rgba(255, 255, 255, 0.75)`) layered over wash status banners with `backdrop-filter: blur(12px)` and a subtle `1px` inner border (`rgba(255, 255, 255, 0.6)`).

## Shapes

The interface embraces generous, organic contours reflecting fabric fluidity, rolled towels, and gentle water cycles.

- Standard buttons, text inputs, and listing tiles utilize balanced rounded corners (`0.5rem` / `8px`).
- Category cards, promotional banners, and booking summaries scale upward to expressive curves (`1rem` to `1.5rem` / `rounded-2xl` & `rounded-3xl`) to establish friendly luxury.
- Badges, status markers, and stepper indicators use full pills (`9999px`).

## Components

### Buttons
- **Primary Action**: Solid `#5B21B6` background, crisp `#FFFFFF` label, height 52dp on mobile for effortless thumb tap. Pressed state deepens to `#4C1D95`.
- **Secondary & Quick-Add**: Soft lavender wash (`#EDE9FE`) with `#5B21B6` typography and hover/tap border reinforcement.
- **Floating Cart / Booking Bar**: Docked to screen bottom with pill geometry, housing item count, live price (`₹840`), and forward chevron.

### Category & Service Cards
- Pure white container over `#F5F3FF`. Contains an icon or crisp fabric photography, service title, pricing cue (`Starts at ₹49/pc`), and an expressive rounded container (`rounded-2xl`). Active service cards outline in a 2px `#7C3AED` border.

### Status Chips & Badges
- **Glassmorphic Service Badges**: `rgba(255, 255, 255, 0.85)` with light border and emerald/violet indicator dots.
- **Order Progress Pills**: 
  - *Active / Pickup Scheduled*: Warm Amber tint (`#FEF3C7` background, `#B45309` text).
  - *Processing & Ozone Wash*: Lavender Indigo tint (`#EDE9FE` background, `#6D28D9` text).
  - *Delivered & Ready*: Mint tint (`#D1FAE5` background, `#047857` text).

### Navigation & Bottom Tab Bar
- Mobile Android-optimized floating navigation bar with soft top blur (`rgba(255, 255, 255, 0.92)`). Active tabs display solid purple icons accented with a micro pill dot underneath, while inactive tabs adopt muted slate (`#64748B`).

### Interactive Form Inputs & Date Pickers
- Time-slot and pickup-day selector pills arranged horizontally in a swipeable rail. Selected slot features `#5B21B6` solid fill with bright white text, unselected slots carry `#FFFFFF` fill with `#E2E8F0` border.
- Rupee pricing fields display the `₹` prefix locked in bold slate weight.